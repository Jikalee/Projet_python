import csv
from flask import Flask, render_template, request

app = Flask(__name__)

class EnregistreurDonnees:
    def __init__(self):
        self.donnees = []

    def enregistrer(self, email, intention_de_quitter_pays, age, niveau_d_etude,
                    pays_vise, raison_du_depart, objectif_du_depart,
                    duree_prevue_a_l_etranger, intention_de_retour_dans_le_pays_d_origine):
        self.donnees.append({
            'email': email,
            'intention_de_quitter_pays': intention_de_quitter_pays,
            'age': age,
            'niveau_d_etude': niveau_d_etude,
            'pays_vise': pays_vise,
            'raison_du_depart': raison_du_depart,
            'objectif_du_depart': objectif_du_depart,
            'duree_prevue_a_l_etranger': duree_prevue_a_l_etranger,
            'intention_de_retour_dans_le_pays_d_origine': intention_de_retour_dans_le_pays_d_origine
        })
        self.sauvegarder()

  
    def sauvegarder(self):
       with open('donnees.csv', 'a', newline='') as fichier:
        # Écrire chaque ligne avec deux-points (:) après chaque champ
        for donnee in self.donnees:
            for champ, valeur in donnee.items():
                fichier.write(f"{champ}: {valeur}\n")
            fichier.write('.' * 50 + '\n')  # Ajouter une ligne de points de suspension entre les blocs de données

  

    def charger(self):
        try:
            with open('donnees.csv', 'r') as fichier:
                reader = csv.reader(fichier)
                for ligne in reader:
                    print(ligne)
        except FileNotFoundError:
            print("Le fichier n'existe pas")
            self.donnees   =[]
        except csv.UnpicklingError as e: 
            print(f"Erreur lors du chargement des données : {e}")
            self.donnees = []    


enregistreur = EnregistreurDonnees()
enregistreur.charger()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        email = request.form['email']
        intentions_quitter_pays = request.form['intentions_quitter_pays']
        age = request.form['age']
        niveau_d_etudes = request.form['niveau_d_etudes']
        pays_vise = request.form.getlist('pays_vise')
        raison_du_depart = request.form.getlist('raison_du_depart')
        objectif_du_depart = request.form.getlist('objectif_du_depart')
        duree_prevue_a_l_etranger = request.form['duree_prevue_a_l_etranger']
        intention_de_retour_dans_le_pays_d_origine = request.form['intention_de_retour_dans_le_pays_d_origine']

        enregistreur.enregistrer(email, intentions_quitter_pays, age, niveau_d_etudes, pays_vise, raison_du_depart, objectif_du_depart, duree_prevue_a_l_etranger, intention_de_retour_dans_le_pays_d_origine)

        return render_template('formulaire_questions.html')

    return render_template('formulaire_questions.html')  # Ajout de cette ligne pour renvoyer une réponse en cas de méthode GET


@app.route('/donnees', methods=['GET'])
def obtenir_donnees():
    return str(enregistreur.donnees)

if __name__ == '__main__':
    app.run(debug=True)
